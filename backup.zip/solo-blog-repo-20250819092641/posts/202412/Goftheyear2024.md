title: G of the year 2024
date: '2024-12-22 21:13:53'
updated: '2025-05-13 19:47:52'
tags: [旅游, 年终征文2024, 感悟, 总结]
permalink: /summary2024
---
> 2024 —— 我可能是我这辈子最爽的一年

## 一月份

由于职业调整，我开启流浪中国计划，也是受了各大up主的影响

![image.png](https://file.fishpi.cn/2023/12/image-6cb6afb0.png)

一次说走就走的旅行，是给自己的奖励，毕竟工作5年没有旅游过。

<iframe src="https://player.bilibili.com/player.html?aid=1200442888&bvid=BV1XF4m1T7kN&cid=26145655408&p=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width="1000"height="500"> </iframe>

### 香港

元朗抽象艺术:art:
去香港没有玩什么 ，walk了一下，吃了一个叉烧肠粉，感觉一般，主要是去香港ariport飞北京。

![image.png](https://file.fishpi.cn/2024/12/image-c4e2b939.png)

香港国际jīchăng![image.png](https://file.fishpi.cn/2024/12/image-42890226.png)
第一次做空客330 大飞机，还能看电影打游戏

### 北京

北京跨年，4天3晚

第一次滑雪，单板之神
然后就感冒了

![image.png](https://file.fishpi.cn/2024/12/image-ff8e58bb.png)
跨完年回深，感冒休息了几天，就又出发了

### 杭州

夜晚的西湖（真的很冷）

![image.png](https://file.fishpi.cn/2024/12/image-f5813a91.png)

灵隐寺,韦陀菩萨好飒

寻找亮点

![image.png](https://file.fishpi.cn/2024/12/image-6fe2dcae.png)

![image.png](https://file.fishpi.cn/2024/12/image-76b8ad5f.png)

![image.png](https://file.fishpi.cn/2024/12/image-4c753e32.png)

### 上海

第一次去上海,和前同事聚了一下,去了外滩，然后感冒又复发了，在上海酒店躺了2天，迷上了zywoo的集锦

![image.png](https://file.fishpi.cn/2024/12/image-cf949d0b.png)

### 苏州

苏州这个城市处处透露着江南风情,走在路上随处可见的石桥,情绪价值很足.
去了寒山寺和西园寺还有拙政园，平江路

![image.png](https://file.fishpi.cn/2024/12/image-5e4880e9.png)

![image.png](https://file.fishpi.cn/2024/12/image-ef9248d1.png)

![image.png](https://file.fishpi.cn/2024/12/image-a39966e0.png)

![image.png](https://file.fishpi.cn/2024/12/image-0840d03f.png)

![image.png](https://file.fishpi.cn/2024/12/image-10bb2977.png)

![image.png](https://file.fishpi.cn/2024/12/image-be98437c.png)

### 南京

中山陵,明孝陵,美龄宫,总统府 鸡鸣寺

![image.png](https://file.fishpi.cn/2024/12/image-23ada798.png)

![image.png](https://file.fishpi.cn/2024/12/image-6328714c.png)

![image.png](https://file.fishpi.cn/2024/12/image-73ba81d9.png)

### 合肥

路过,吃了芜湖红皮鸭子

![image.png](https://file.fishpi.cn/2024/12/image-c8cf5be8.png)

### 黄山

五岳归来不看山,黄山归来不看岳
黄山是值得去多次的地方，虽然贵

![image.png](https://file.fishpi.cn/2024/12/image-92bfa3bd.png)

![image.png](https://file.fishpi.cn/2024/12/image-b5f3c630.png)

### 景德镇

世界瓷都，江西菜是真的辣，可以尝试一下牛骨粉

![image.png](https://file.fishpi.cn/2024/12/image-8850cb6b.png)

![image.png](https://file.fishpi.cn/2024/12/image-636371d0.png)

### 郑州

和小学同学见面,互相寒暄,他在郑州开了一家菜鸟驿站,特意出来和我去了只有河南戏剧幻城,很好的地方

![image.png](https://file.fishpi.cn/2024/12/image-9c313ed5.png)

### 平遥

黑神话悟空取景地,双林寺和镇国寺
双林寺的彩塑和镇国寺的木构建筑，平遥双圣

![image.png](https://file.fishpi.cn/2024/12/image-0e7a0c0e.png)

![image.png](https://file.fishpi.cn/2024/12/image-8fc068de.png)

![image.png](https://file.fishpi.cn/2024/12/image-fb756637.png)

### 西安

兵马俑很震撼,水盆羊肉很好吃

![image.png](https://file.fishpi.cn/2024/12/image-5772c21f.png)

![image.png](https://file.fishpi.cn/2024/12/image-7cacd850.png)

### 重庆

网红城市,不过我喜欢

![image.png](https://file.fishpi.cn/2024/12/image-f936f8c6.png)

大足石刻 黑神话悟空取景地, 现场看真的很壮观

![image.png](https://file.fishpi.cn/2024/12/image-e87f251f.png)

不空,是你

![image.png](https://file.fishpi.cn/2024/12/image-01034d49.png)

1比1复刻镜头

![image.png](https://file.fishpi.cn/2024/12/image-40c2f50f.png)

### 成都

去了新津观音寺,看到了几百年前的壁画

![image.png](https://file.fishpi.cn/2024/12/image-b7b63e4f.png)

![image.png](https://file.fishpi.cn/2024/12/image-cc61c460.png)

![image.png](https://file.fishpi.cn/2024/12/image-2723bee4.png)

### 大理

苍山洱海, 很文艺的地方,四季如春,很适合旅居

![image.png](https://file.fishpi.cn/2024/12/image-7341f33d.png)

![image.png](https://file.fishpi.cn/2024/12/image-5c9cce6a.png)

![image.png](https://file.fishpi.cn/2024/12/image-f370f680.png)

## 二月份到十月份

纯纯的打游戏和健身两点一线

1. 艾尔等法环
2. 匹诺曹的谎言
3. 黑暗之魂3
4. 赛博朋克2077
5. 荒野大镖客2
6. 暖雪
7. 山河旅探
8. 美女请别影响我学习
9. 博德之门3
10. 土豆兄弟
11. 对马岛之魂
12. 战神4
13. 暗影火炬城
14. 空洞骑士
15. 名利游戏
16. 最后生还者2
17. 记忆边境
18. 烟火
19. 钢之崛起
20. 饿殍 明末行千里
21. 女鬼桥2
22. sifu
23. 港诡实录
24. 仁王2
25. 跳跳大佬的无尽迷宫
26. 三国志14
27. CS2
28. 堕落之主
29. NBA2k25

然后荣幸获得了影之刃零官方的邀请,参与了BW2024 影之刃零的试玩活动

![image.png](https://file.fishpi.cn/2024/12/image-68e15405.png)

![image.png](https://file.fishpi.cn/2024/12/image-a221ef68.png)

![image.png](https://file.fishpi.cn/2024/12/image-79893d0d.png)

然后8月份玩了黑神话悟空,也算完成23年末的一个心愿

国庆参加了两个同学的婚礼 https://fishpi.cn/article/1728626923166

体重也相比23年底减了20斤左右

![IMG_5855.PNG](https://file.fishpi.cn/2024/12/IMG5855-f791016d.PNG)

## 十一月

开始有了危机感,不能在这么颓废下去了,开始了找工作之旅

https://fishpi.cn/article/1732278084294

https://fishpi.cn/article/1732342248234

https://fishpi.cn/article/1732500574628

https://fishpi.cn/article/1732501483123

https://fishpi.cn/article/1733549670846

## 十二月份

到了十二月份,我回到了长沙工作, 我一直清醒的认识到我总有一天会回到长沙,但这一刻来临的时候我才知道现在到时候了

![image.png](https://file.fishpi.cn/2024/12/image-4e47c698.png)
