title: K8S deployment模板
date: '2020-10-26 15:12:05'
updated: '2020-10-27 15:08:08'
tags: [Kubernetes]
permalink: /articles/2020/10/26/1603696325372.html
---
![](https://b3logfile.com/bing/20191028.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> deployment 是 k8s中的无状态服务控制器 ，定义一组Pod期望数量，deployment 会维持Pod数量与期望数量一致。一些无状态的服务可以使用deployment进行部署。 这里以nmap-driver为例,作为一个部署deployment服务的模板。

首先创建三个文件`cm.yaml`,`nmap-driver.ymal`,`svc.yaml`

## svc.yaml

> 这是service 模板文件，用来提供外部访问服务。

~~~yaml
apiVersion: v1
kind: Service
metadata:
  name: nmap-driver
  namespace: sky
  labels:
    app: nmap-driver
spec:
  ports:
  - name: grpc
    targetPort: 19999
    port: 19999
  clusterIP: None
  selector:
    app: nmap-driver
---
apiVersion: v1
kind: Service
metadata:
  name: nmap-driver-service
  namespace: sky
  labels:
    app: namp-driver
spec:
  externalIPs:               # 暴露Service到外部IP
  - 192.168.1.146                # IP
  selector:
    app: namp-driver
  ports:
  - name: grpc
    targetPort: 19999
    port: 19999

~~~

## cm.yaml

> 使用configmap 管理配置文件。

~~~yaml
kind: ConfigMap
metadata:
  name: nmap-driver-config
  namespace: sky
  labels:
    addonmanager.kubernetes.io/mode: Reconcile
data:
    config.ini: |
          [Nmap-Driver]
          port=19999
    logging.conf: |
          [loggers]
          keys=root

          [handlers]
          keys=allHandler,errorHandler

          [formatters]
          keys=simpleFormatter,detailFormatter

          [logger_root]
          level=DEBUG
          handlers=allHandler,errorHandler

          [handler_allHandler]
          class=logging.handlers.TimedRotatingFileHandler
          args=('/root/log/all.log', 'D',1,7)
          level=DEBUG
          formatter=simpleFormatter
    
          [handler_errorHandler]
          class=logging.handlers.TimedRotatingFileHandler
          args=('/root/log/error.log', 'D',1,7)
          level=ERROR
          formatter=detailFormatter

          [formatter_simpleFormatter]
          format=%(asctime)s - %(levelname)s - %(message)s

          [formatter_detailFormatter]
          format=%(asctime)s - %(levelname)s - %(filename)s[:%(lineno)d] - %(message)s
~~~

## nmap-driver.yaml

> deployment 文件 设置副本数，配置启动镜像 启动参数 挂载配置文件

~~~yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nmap-driver
  namespace: sky
spec:
  replicas: 1
  selector:
    matchLabels:
      app: nmap-driver
  template:
    metadata:
      name: nmap-driver
      labels:
        app: nmap-driver
    spec:
      tolerations:
      - key: "node.kubernetes.io/unreachable"
        operator: "Exists"
        effect: "NoExecute"
        tolerationSeconds: 60
      - key: "node.kubernetes.io/not-ready"
        operator: "Exists"
        effect: "NoExecute"
        tolerationSeconds: 60
      terminationGracePeriodSeconds: 0                # 异常立即删除
      containers:
      - name: nmap-driver
        securityContext:
          privileged: true
        imagePullPolicy: IfNotPresent
        image: hub.sky-cloud.net/sky/nmap-driver:master_build-4
  
        ports:
        - name: grpc
          containerPort: 19999
        env:
        - name: TZ
          value: Asia/Shanghai
        volumeMounts:
        - name: tz
          mountPath: /etc/localtime
        - name: log
          mountPath: /root/log    #将容器内的这个日志目录挂载到外部/srv/sky/nmap-driver/log
        - name: config
          mountPath: /nmap-driver/config    #configmap中的配置文件 挂载到容器的这个文件夹
      volumes:
      - name: tz
        hostPath:
          path: /etc/localtime
      - name: log
        hostPath:
          path: /srv/sky/nmap-driver/log
      - name: config
        configMap:
          name: nmap-driver-config
          items:
          - key: config.ini
            path: config.ini
          - key: logging.conf
            path: logging.conf
~~~

## 启动

使用kubelet  命令启动

~~~shell
kubectl apply -f .
~~~

根据这个模板   只需一下几个步骤就可启动一个deployment服务

1. 替换项目名和namespace
2. 替换svc.yaml里面的ip和端口
3. 在cm.yaml里面放入配置文件
4. 挂载日志文件目录和config
5. 替换镜像
