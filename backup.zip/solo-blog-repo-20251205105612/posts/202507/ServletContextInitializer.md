title: ServletContextInitializer
date: '2025-07-15 10:56:52'
updated: '2025-07-15 11:04:33'
tags: [java, SpringBoot, servlet]
permalink: /articles/2025/07/15/1752548212181.html
---
![](https://b3logfile.com/bing/20210920.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> ServletContextInitializer 是 Spring Boot 提供的一个接口，允许你在内嵌 Servlet 容器（如 Tomcat）启动时，自定义注册 Servlet、Filter、Listener 或修改 ServletContext 属性。

```java
@FunctionalInterface
public interface ServletContextInitializer {
    void onStartup(ServletContext servletContext) throws ServletException;
}
```

这个接口会在内嵌容器启动时自动被调用（等价于 web.xml 的内容）。

## 它和Bean的生命周期的关系？

它不是 Bean 的生命周期钩子，但它是由 Spring Boot 的 ServletWebServerApplicationContext 在 Web 容器启动前主动调用的。

大概在 Spring 完成 ApplicationContext.refresh() 时：

```java
// 调用所有 ServletContextInitializer 的 onStartup()
this.selfInitialize(servletContext);
```

## Lab

### 注册一个原始 Servlet（不使用 @WebServlet）

```java
@Component
public class MyServletInitializer implements ServletContextInitializer {
    @Override
    public void onStartup(ServletContext servletContext) {
        ServletRegistration.Dynamic servlet = servletContext.addServlet("myServlet", new MyCustomServlet());
        servlet.addMapping("/custom");
        servlet.setLoadOnStartup(1);
    }
}
```

等效于 web.xml 的配置：

```xml
<servlet>
  <servlet-name>myServlet</servlet-name>
  <servlet-class>com.example.MyCustomServlet</servlet-class>
</servlet>
<servlet-mapping>
  <servlet-name>myServlet</servlet-name>
  <url-pattern>/custom</url-pattern>
</servlet-mapping>
```

### 注册一个 Filter

```java
@Component
public class MyFilterInitializer implements ServletContextInitializer {
    @Override
    public void onStartup(ServletContext servletContext) {
        FilterRegistration.Dynamic filter = servletContext.addFilter("myFilter", new MyFilter());
        filter.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST), true, "/*");
    }
}
```

### 注册一个 Listener

```java
@Component
public class MyListenerInitializer implements ServletContextInitializer {
    @Override
    public void onStartup(ServletContext servletContext) {
        servletContext.addListener(MySessionListener.class);
    }
}
```

## Spring Boot 自动适配的变种接口

Spring Boot 自动支持以下扩展：


| 接口 / 注解                                               | 说明                               |
| ----------------------------------------------------------- | ------------------------------------ |
| ServletContextInitializer                                 | 最底层的原始注册能力               |
| @ServletComponentScan+@WebServlet/@WebFilter/@WebListener | 注解式注册（Spring Boot 自动支持） |
| FilterRegistrationBean,ServletRegistrationBean            | Spring Boot 提供的注册工具类       |

### FilterRegistrationBean

这本质上最终也会被转换为 ServletContextInitializer 调用。

```java
@Bean
public FilterRegistrationBean<MyFilter> myFilter() {
    FilterRegistrationBean<MyFilter> registration = new FilterRegistrationBean<>();
    registration.setFilter(new MyFilter());
    registration.addUrlPatterns("/*");
    return registration;
}
```

## 常见高级用途


| 目标                              | 实现方式                                      |
| ----------------------------------- | ----------------------------------------------- |
| 注册动态 SSE Servlet              | 用ServletContextInitializer注册 SSE Servlet   |
| 手动配置 ServletContext 的参数    | servletContext.setInitParameter("xxx", "yyy") |
| 与非 Spring 的旧 Servlet 框架桥接 | 注册第三方原生 Servlet（如 Swagger、Shiro）   |
| 替代 web.xml                      | 全部 Servlet/Filter/Listener 配置转移到 Java  |

## 注意

springboot内嵌的tomcat容器，是无法在启动之后动态add一个servlet的

~~~java
    private ServletRegistration.Dynamic addServlet(String servletName, String servletClass, Servlet servlet,
            Map<String,String> initParams) throws IllegalStateException {

        if (servletName == null || servletName.isEmpty()) {
            throw new IllegalArgumentException(sm.getString("applicationContext.invalidServletName", servletName));
        }

        // 这里会检查容器状态，只有容器启动之前能够注册，启动之后注册会报错 IllegalStateException
        checkState("applicationContext.addServlet.ise");

        Wrapper wrapper = (Wrapper) context.findChild(servletName);

        // Assume a 'complete' ServletRegistration is one that has a class and
        // a name
        if (wrapper == null) {
            wrapper = context.createWrapper();
            wrapper.setName(servletName);
            context.addChild(wrapper);
        } else {
            if (wrapper.getName() != null && wrapper.getServletClass() != null) {
                if (wrapper.isOverridable()) {
                    wrapper.setOverridable(false);
                } else {
                    return null;
                }
            }
        }

        ServletSecurity annotation = null;
        if (servlet == null) {
            wrapper.setServletClass(servletClass);
            Class<?> clazz = Introspection.loadClass(context, servletClass);
            if (clazz != null) {
                annotation = clazz.getAnnotation(ServletSecurity.class);
            }
        } else {
            wrapper.setServletClass(servlet.getClass().getName());
            wrapper.setServlet(servlet);
            if (context.wasCreatedDynamicServlet(servlet)) {
                annotation = servlet.getClass().getAnnotation(ServletSecurity.class);
            }
        }

        if (initParams != null) {
            for (Map.Entry<String,String> initParam : initParams.entrySet()) {
                wrapper.addInitParameter(initParam.getKey(), initParam.getValue());
            }
        }

        ServletRegistration.Dynamic registration = new ApplicationServletRegistration(wrapper, context);
        if (annotation != null) {
            registration.setServletSecurity(new ServletSecurityElement(annotation));
        }
        return registration;
    }
~~~
