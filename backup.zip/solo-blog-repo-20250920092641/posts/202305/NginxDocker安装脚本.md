title: Nginx Docker 安装脚本
date: '2023-05-26 15:41:54'
updated: '2023-06-01 17:40:31'
tags: [脚本, nginx, Docker]
permalink: /articles/2023/05/26/1685086913864.html
---
![](https://b3logfile.com/bing/20200216.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

自己多次搭建nginx做站点反向代理，这里将命令组合成脚本，方便日后使用。

~~~bash
#!/bin/sh

mkdir /srv/nginx/config

echo -e "user  nginx;\nworker_processes  auto;\n\nerror_log  /var/log/nginx/error.log notice;\npid        /var/run/nginx.pid;\n\n\nevents {\n    worker_connections  1024;\n}\n\n\nhttp {\n    include       /etc/nginx/mime.types;\n    default_type  application/octet-stream;\n\n    log_format  main  '\$remote_addr - \$remote_user [\$time_local] \"\$request\" '\n                      '\$status \$body_bytes_sent \"\$http_referer\" '\n                      '\"\$http_user_agent\" \"\$http_x_forwarded_for\"';\n\n    access_log  /var/log/nginx/access.log  main;\n\n    sendfile        on;\n    #tcp_nopush     on;\n\n    keepalive_timeout  65;\n\n    #gzip  on;\n\n    include /etc/nginx/conf.d/*.conf;\n}" >> /srv/nginx/config/nginx.conf

docker pull nginx
docker run -d --name=nginx -p 80:80 -v /srv/nginx/config/nginx.conf:/etc/nginx/nginx.conf nginx
~~~

`nginx.conf`配置文件挂载在目录 `/srv/nginx/config` 方便修改
