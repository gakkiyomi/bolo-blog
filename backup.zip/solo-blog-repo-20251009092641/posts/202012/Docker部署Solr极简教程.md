title: Docker部署Solr极简教程
date: '2020-12-16 21:40:57'
updated: '2025-05-11 10:30:52'
tags: [solr, 搜索, Docker]
permalink: /articles/2020/12/16/1608126057324.html
---
![](https://b3logfile.com/bing/20180102.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> solr是apache旗下的一款开源，高效的搜索引擎，底层使用的apache的lucene。这篇文章将以极简的方式搭建单机版的solr。本教程旨在试玩与学习，生产环境搭建还请移步官方文档与相关社区。

我作为一个solr新手来搭建环境时，首先肯定是从官方文档的quick start开始啦,但是官方文档里面居然没有docker安装的教程，这对新时代的我来说是无法接受的。但是网上的各种docker安装教程不知道是因为solr镜像版本的原因还是其他原因，在我使用data-import的功能时，各种目录对不上，以及各种sdk和api介绍搞得我眼花缭乱，无用的信息太多只会让自己的脑子发热以及打击自信心。

所以在探索出我要的东西之后，决定写下这个教程只服务于docker安装以及data-import功能介绍和使用。如若与您所需要的东西不符，那也没必要看下去了。

在安装前请确保服务器能连接互联网与存在docker服务。

### 提示

**本文只介绍solr的docker安装与data-import功能对于postgresql的使用。如需了解solr的api或者sdk的使用请移步官方文档与相关社区。**

### 下载镜像

直接在docker里面下载官方镜像，以最新版为例。

~~~shell
docker pull solr
~~~

![image.png](https://b3logfile.com/file/2020/12/image-81bc4ba8.png)

### 准备工作

+ 需要创建工作目录，方便我们挂载配置文件，用来测试solr的data-import功能

  ![image.png](https://b3logfile.com/file/2020/12/image-f9143340.png)

```
创建data目录用来挂载配置文件 空的就行启动后docker会把容器内的配置文件复制出来
```

```
创建lib目录放置postgres-jdbc-driver的jar包
```

+ 准备postgres-jdbc-driver的jar包

  下载好jar包放入lib目录

![image.png](https://b3logfile.com/file/2020/12/image-8bded0da.png)

### 启动容器

~~~shell
docker run -d -p 8983:8983 -v /srv/solr/lib:/data-lib -v /srv/solr/data/:/var/solr/data -t --privileged=true  --name solr solr
~~~

启动完成后已root用户进入docker容器

~~~shell
docker exec -it -u root solr bash
~~~

在容器里将/data-lib目录下的jdbc-driver包cp到`/opt/solr-8.7.0/server/solr-webapp/webapp/WEB-INF/lib`

在容器里将`/opt/solr-8.7.0/dist/solr-dataimporthandler-8.7.0.jar`cp到`/opt/solr-8.7.0/server/solr-webapp/webapp/WEB-INF/lib`

![image.png](https://b3logfile.com/file/2020/12/image-ba575c6e.png)

到这里就可以打开solr的admin控制页面了

访问目标ip的8983端口 `192.168.1.222:8983`

![image.png](https://b3logfile.com/file/2020/12/image-e52a0f87.png)

### 创建一个新的索引库

~~~shell
docker exec -it --user=solr solr bin/solr create_core -c nap
~~~

由于我的配置文件挂载到宿主机上了，所以我们只要修改宿主机上的文件即可。

进入宿主机上新建立的data目录，这时候我们创建的索引库已经在文件夹里生成了

![image.png](https://b3logfile.com/file/2020/12/image-5b5e8aaf.png)

### 写入solrconfig.xml

进入目标索引库的conf目录

![image.png](https://b3logfile.com/file/2020/12/image-b63636be.png)

在这个/selcet所在的标签上面新添加一个标签

![image.png](https://b3logfile.com/file/2020/12/image-97247c82.png)

~~~xml
<requestHandler name="/dataimport"
            class="org.apache.solr.handler.dataimport.DataImportHandler">
            <lst name="defaults">
            <str name="config">data-config.xml</str>
            </lst>
  </requestHandler>
~~~

### 写入data-config.xml

在conf目录添加data-config.xml

~~~xml
<?xml version="1.0" encoding="UTF-8"?>
<dataConfig>
    <dataSource type="JdbcDataSource" driver="org.postgresql.Driver" url="jdbc:postgresql://192.168.1.54:5432/nap2"  user="postgres" password="r00tme"/>
　　<document name="test">
        <entity name="test" pk="id"
 query="select id,created_at,deleted from test">
　　　      <field column="id" name="id"/>
            <field column="created_at" name="created_at"/>
            <field column="deleted" name="deleted"/>
　　　  </entity>
　　</document>
</dataConfig>

[root@nap-222 conf]#
~~~

里面填上自己的数据源，支持多个和多种数据源，按规则配置即可

### 写入managed-schema

![image.png](https://b3logfile.com/file/2020/12/image-43f68ea8.png)

添加相应的field , id默认不能删除，_version_也不能删除，删除solr启动会报错。

### 重启容器

~~~shell
docker restart solr
~~~

### 在admin控制台手动同步数据

![image.png](https://b3logfile.com/file/2020/12/image-45453700.png)

### 查询数据

![image.png](https://b3logfile.com/file/2020/12/image-190dd4e7.png)

### 修改postgres源数据solr是否能触发同步?

修改数据源里的数据solr不会察觉同步，所以需要自己维护，例如api通知，或者使用sorl的插件可以设置定时同步与轮询。

### 总结

本文作为一个新手试玩教程应该还算是比较简单明了，如果按照此教程安装有不懂的也可以在评论区留言，欢迎交流，斧正。
