title: Fastjson 重复引用对象的问题
date: '2021-03-19 17:48:04'
updated: '2023-06-01 17:38:37'
tags: [JAVA]
permalink: /articles/2021/03/19/1616147284941.html
---
# Fastjson 重复引用对象的问题

出现相同的对象时，fastjson默认开启引用检测将相同的对象写成引用的形式

引用是通过"$ref"来表示的


| 引用                  | 描述                                             |
| :---------------------- | :------------------------------------------------- |
| "$ref":".."           | 上一级                                           |
| "$ref":"@"            | 当前对象，也就是自引用                           |
| "$ref":"$"            | 根对象                                           |
| "$ref":"$.children.0" | 基于路径的引用，相当于 root.getChildren().get(0) |

## 复现

~~~java

    public static void main(String[] args) {
        final JSONObject src = new JSONObject();
        src.put("a", "b");
        src.put("c", "d");
        src.put("e", "f");
        final JSONObject object = new JSONObject();
        object.put("src", src);
        object.put("target", src);

        System.out.println(object.toJSONString());
    }
~~~

输出:

~~~java
{"src":{"a":"b","c":"d","e":"f"},"target":{"$ref":"$.src"}}

Process finished with exit code 0
~~~

## 解决办法

使用 `DisableCircularReferenceDetect`来禁止循环引用检测

~~~java
//在可以添加SerializerFeature参数的地方添加此配置项即可
System.out.println(object.toString(SerializerFeature.DisableCircularReferenceDetect));
~~~

输出:

~~~java
{"src":{"a":"b","c":"d","e":"f"},"target":{"a":"b","c":"d","e":"f"}}

Process finished with exit code 0
~~~
