title: arthas 使用教程
date: '2023-07-21 14:10:20'
updated: '2023-07-21 14:11:41'
tags: [运维, JAVA]
permalink: /articles/2023/07/21/1689919820060.html
---
![](https://b3logfile.com/bing/20171222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# arthas 使用教程

> Arthas 是Alibaba开源的Java诊断工具，通过这个工具我们可以快速并准确的定位问题。
>
> 这里会简单介绍使用arthas进行Troube Shooting，详细安装流程与深入的操作命令参数请自行查阅官方文档学习。🙏

**官方文档:** [https://arthas.aliyun.com/doc/index.html](https://arthas.aliyun.com/doc/index.html)

## 资源监控

arthas提供了CPU，内存，运行环境等资源信息面板,并且可以设置刷新时间

### 命令

#### dashboard

![image.png](https://b3logfile.com/file/2021/03/image-87b8067c.png)

#### heapdump

dump java heap, 类似jmap命令的heap dump功能。

查看java 堆内存的对象实例情况

`heapdump /arthas-output/nap.hprof`  将堆的使用情况dump到 /arthas-output/nap.hprof 文件

可以使用jdk自带的 `VisualVM`来查看

![image.png](https://b3logfile.com/file/2021/03/image-fa22cc7e.png)

也可以使用IntelliJ IDEA 自带的 HPROF 内存查看器 查看  输入Action `Open profiler Snapshot`

![image.png](https://b3logfile.com/file/2021/03/image-b5ed4494.png)

#### Profiler

> arthas支持监控一段时间的火焰图来统计性能热点。

`profiler start`  启动搜集CPU的使用情况

`profiler stop`  从start 到 stop这个时间段的CPU火焰图

![image.png](https://b3logfile.com/file/2021/03/image-3ae478b4.png)

**火焰图里，X轴越长,代表使用的越多,Y轴是调用堆栈信息**。当前收集的是什么类型的数据，比如cpu 那么x轴长度越大,占用的cpu资源就越多。

#### thread

> 查看当前线程信息，查看线程的堆栈


| 参数名称     | 参数说明                                             |
| -------------- | ------------------------------------------------------ |
| *id*         | 线程id                                               |
| [n:]         | 指定最忙的前N个线程并打印堆栈                        |
| [b]          | 找出当前阻塞其他线程的线程                           |
| [i`<value>`] | 指定cpu使用率统计的采样间隔，单位为毫秒，默认值为200 |
| [--all]      | 显示所有匹配的线程                                   |

查看当前最吃资源的线程

![image.png](https://b3logfile.com/file/2021/03/image-1a574aff.png)

## 方法调用时间追踪

### 命令

#### trace

> 使用trace命令可以针对某一类的某一方法进行方法调用时间的追踪,精确定位到问题所在。
>
> 使用建议：
>
> 1. 首先使用thread命令查看当前高占用线程堆栈定位到方法
> 2. 然后使用trace监控方法进行用时追踪

![image.png](https://b3logfile.com/file/2021/03/image-99aeabcc.png)

## 在线热更新

arthas允许我们修改一个正在运行的字节码文件，也允许我们从外部加载一个新的claas文件来覆盖旧的。这样我们可以实现在线热部署，这样可以临时性的解决客户生产环境产生的问题,例如空指针异常😂。

### 命令

jad/mc/retransform 组合可实现热更新

#### jad

反编译代码，将已加载的字节码文件反编译到容器内文件夹。现场操作人员可以直接修复问题(如果问题够简单)

`jad --source-only net.skycloud.cmdb.resource.api.rest.ResourceSearchController > /tmp/ResourceSearchController.java`

![image.png](https://b3logfile.com/file/2021/03/image-4d8bf68d.png)

修改反编译出来的class文件 (除法分母不能为0)

![image.png](https://b3logfile.com/file/2021/03/image-d2c05e85.png)

#### mc

Memory Compiler/内存编译器，编译 `.java`文件生成 `.class`。 这也是我们可以从 **外部加载java文件(打补丁)** 的基础。

若前方技术支持无法解决，可以让后端伙伴进行bug修复，然后传输修复后的java文件来以解燃眉之急。不需要重新生成镜像。

`mc /tmp/ResourceSearchController.java -d /tmp`

![image.png](https://b3logfile.com/file/2021/03/image-72adb642.png)

#### retransform

加载外部的 `.class`文件，retransform(重新转换) jvm已加载的类。

`retransform /tmp/net/skycloud/cmdb/resource/api/rest/ResourceSearchController.class`

![image.png](https://b3logfile.com/file/2021/03/image-6bc39bcd.png)

##### 查看已更新的类

`retransform -l`

![image.png](https://b3logfile.com/file/2021/03/image-c15e45a5.png)

##### 恢复原来的类

这两个命令一起执行

`retransform --deleteAll`

`retransform --classPattern net.skycloud.cmdb.resource.api.rest.ResourceSearchController`

## Troube Shooting

作为在现场的工作人员需要至少需要掌握以上命令来进行诊断。troube shooting流程如下。

![image.png](https://b3logfile.com/file/2021/03/image-d3427379.png)
