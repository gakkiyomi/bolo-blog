title: Java 标准库API系列之Exchanger
date: '2023-05-28 18:39:56'
updated: '2023-06-01 17:38:18'
tags: [JAVA]
permalink: /articles/2023/05/28/1685270396773.html
---
![](https://b3logfile.com/bing/20190321.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 作为一名java程序员，熟练掌握java提供的标准库是非常必要的，所以有了Java 标准库API系列文章来介绍java标准库里的一些常用的工具类，了解这些标准库可以从中学习到大神贡献给java的优良的代码和理解一些操作系统的原理，例如并发等等。。。

本文会介绍juc包下的`Exchanger`类。

> java.util.concurrent 包是 Java 5.0 提供的并发工具包(简称 JUC)包, 主要有原子操作 CAS，锁机制 AQS（可重入锁，闭锁，屏障锁等）， 并发集合（Map，Queue 等），线程池（线程池执行器，调度线程池执行器和执行器），Exchanger是Java中的一个同步工具类，它提供了一个同步点，允许两个线程在这个同步点交换数据。Exchanger实现了一种简单的交换数据模型，可以用于解决线程间通信和同步的问题。

Exchanger的常用方法有两个：

* exchange(V x)：交换数据，当前线程将数据x交换给另一个线程，同时等待另一个线程返回的数据；
* exchange(V x, long timeout, TimeUnit unit)：在指定时间内交换数据，当前线程将数据x交换给另一个线程，同时等待另一个线程返回的数据，如果在指定时间内没有收到返回的数据，则返回null。

以下是一个使用Exchanger进行线程间通信的示例代码：

~~~java
import java.util.concurrent.Exchanger;

public class ExchangerExample {
    private static Exchanger<String> exchanger = new Exchanger<>();

    public static void main(String[] args) {
        Thread t1 = new Thread(() -> {
            String data = "Hello from Thread 1";
            try {
                String receivedData = exchanger.exchange(data);
                System.out.println("Thread 1 received data: " + receivedData);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        Thread t2 = new Thread(() -> {
            String data = "Hello from Thread 2";
            try {
                String receivedData = exchanger.exchange(data);
                System.out.println("Thread 2 received data: " + receivedData);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        t1.start();
        t2.start();
	t1.join();
        t2.join();
    }
}
~~~

在上述代码中，ExchangerExample类中的exchanger变量是一个Exchanger对象，用于在两个线程之间交换数据。在main()方法中，创建了两个线程t1和t2，分别使用exchanger.exchange()方法交换数据。当一个线程调用exchange()方法时，它会阻塞等待另一个线程到达同一个同步点，并将数据交换给它。当两个线程都调用了exchange()方法后，它们都会继续执行，并使用另一个线程返回的数据。

需要注意的是，Exchanger只能用于两个线程之间的数据交换，如果需要在多个线程之间交换数据，需要使用其他同步工具类，如`Semaphore`、`CyclicBarrier`、`CountDownLatch`等。这些api也会在后续**Java 标准库API系列**的其他文章中得到介绍，敬请关注。
