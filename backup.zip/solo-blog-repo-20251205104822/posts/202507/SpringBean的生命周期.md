title: SpringBean 的生命周期
date: '2025-07-07 17:09:38'
updated: '2025-07-07 17:09:38'
tags: [java, Spring]
permalink: /articles/2025/07/07/1751879378671.html
---
![Untitled-diagram-_-Mermaid-Chart-2025-07-02-142134.png](https://file.fishpi.cn/2025/07/UntitleddiagramMermaidChart20250702142134-9816e1cd.png)
