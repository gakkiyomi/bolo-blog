title: 使用@RestControllerAdvice,@Pattern,@Valid实现统一表单参数校验返回
date: '2021-03-06 10:38:52'
updated: '2023-06-01 17:38:50'
tags: [SpringBoot, JAVA]
permalink: /articles/2021/03/06/1614998332204.html
---
![](https://b3logfile.com/bing/20180212.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 使用@RestControllerAdvice,@Pattern,@Valid实现统一表单参数校验返回

表单校验有很多种方法，最直接明了的就是直接在代码里面明编码。

![image.png](https://b3logfile.com/file/2021/03/image-3d2cc9a8.png)

这样子写既不美观也不专业，所以直入正题。

**使用@RestControllerAdvice,@ExceptionHandler,@Pattern,@Valid实现统一表单参数校验返回**
@RestControllerAdvice和@ExceptionHandler一起使用可以捕获controller层抛出的异常,然后我们就可以对期异常返回进行改造。

@Pattern 带有此注解的属性必须与起指定的正则表达式所匹配。

@Valid 带有此注解的对象会对自己的属性检查，如果带有了@Pattern,就进行校验。

结合这四个注解，我们就可以进行表单参数的校验返回了。

~~~java
@RestControllerAdvice
public class CmdbExceptionHandler{

    public CmdbExceptionHandler() {
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    public CommonResponse handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        final FieldError error = e.getBindingResult().getFieldError();
            final String defaultMessage = error.getDefaultMessage();
            return CommonResponse.ofFail(HttpStatus.BAD_REQUEST.value(), defaultMessage, HttpStatus.BAD_REQUEST.name(), e.getMessage());

    }
}
~~~

~~~
@ApiModel("资源过滤器输入")
public class FilterBO {

    @ApiModelProperty(value = "名称", required = true)
    @Pattern(regexp = "^[\\u4e00-\\u9fa5A-Za-z][\\u4e00-\\u9fa5A-Za-z0-9\\-\\_]*$",message = "名称只能由中文,数字,字母,_,-组成")
    private String name;

    @ApiModelProperty(value = "描述", required = false)
    private String description;

    @ApiModelProperty(value = "过滤条件", required = true)
    @NotNull
    public String jql;


}
~~~

然后只要在controller方法里面加上@Valid

![image.png](https://b3logfile.com/file/2021/03/image-2d6228f3.png)

![image.png](https://b3logfile.com/file/2021/03/image-be87e361.png)

这样就达到了我们的目的。🎉🎉🎉🎉
