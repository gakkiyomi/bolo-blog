title: 终于，我打通了bolo 博客与摸鱼派
date: '2025-05-10 20:37:19'
updated: '2025-05-14 18:46:18'
tags: [开源, 博客, 摸鱼派, Bolo]
permalink: /articles/2025/05/10/1746880638954.html
---
2025年了，有人还在用博客吗？苦恼自己的博文评论区没人互动？来试试这款Bolo博客吧。我们怀念黑客派的时光，而正如同从黑客派走向摸鱼派，之前的Solo博客也进化成了Bolo博客。

## Bolo博客

Bolo博客是摸鱼派创始人，用爱发电组织创始人 adlered  https://fishpi.cn/member/adlered 基于Solo的开发演进过来的

> :pineapple:Bolo菠萝博客 专为程序员设计的精致Java博客系统 | :guitar:基于Solo深度定制 | :heart:️完善文档轻松安装，贴心的技术支持 | 免登录评论 | 邮件/微信提醒 | 自定义图床 | 备案模式 | :sparkles:精致主题持续更新 | 一键备份 | 防火墙 | 评论过滤 | 独立分类 | 文章与GitHub同步 | :white_check_mark:安装太轻松！支持 Tomcat Docker 宝塔面板 | 支持Windows Linux MacOS Web容器 | 支持ARM处理器 X86/64处理器 | :truck:支持从Solo轻松迁移

github上1.3K+的star数，源码： https://github.com/adlered/bolo-solo

可以通过 docker快速部署属于你自己的个人博客： https://github.com/adlered/bolo-docker

## 摸鱼派

https://fishpi.cn

> 摸鱼派是以 `摸鱼` 为核心设计语言，`黑客 / 画家` 为用户定位的摸鱼社区。
>
> 在摸鱼派，你可以畅所欲言，聊技术、家常、时事，无论是发帖探讨还是聊天室在线聊天；我们还提供了很多烧脑的小游戏，非常卷的排行榜，欢迎在 `鱼游` 的社区游戏中卷来卷去 :smile:
>
> 希望你会喜欢这里！希望大家可以一起维护摸鱼派，帮助这里变得更好 :heart:️

## 打通他们

今天我对 Bolo 博客系统进行了一个小升级：实现了 **同步摸鱼派文章的评论功能** 。

这也是我一直以来的小目标 —— 将个人博客的内容与社区的互动“打通”。

继之前完成了：

* :white_check_mark: **Bolo 博客文章推送到摸鱼派**
* :white_check_mark: **摸鱼派 Python 客户端将文章推送到 Bolo 博客**

现在，我终于完成了**评论同步**这一关键环节。

:bulb: 简单来说：

* 用户在 **Bolo 博客** 写博文， **一键同步到摸鱼派** ；
* 用户可以在 **Bolo 博客** 一键同步摸鱼派帖子的评论到博文。
  * ![image.png](https://file.fishpi.cn/2025/05/image-14fa336b.png)
* 用户在 **摸鱼派** 上发帖， **使用摸鱼派Python客户端可以推送到博客端** 。
* * ![截屏2025-05-10-19.55.32.png](https://file.fishpi.cn/2025/05/截屏20250510195532-0b38fb52.png)

实现之后，不仅博客的评论区终于“活”了起来，文章也能被社区更多人看到、讨论，实现了内容与互动的双赢。

## 如果你也感兴趣

* 摸鱼派社区源码：[https://github.com/FishPiOffical/rhythm](https://github.com/FishPiOffical/rhythm)
* 摸鱼派 Python 客户端：[https://github.com/FishPiOffical/fishpi-pyclient](https://github.com/FishPiOffical/fishpi-pyclient)
* Bolo 博客系统源码：[https://github.com/adlered/bolo-solo](https://github.com/adlered/bolo-solo)

这三个项目全部开源，代码清晰，社区活跃，你可以根据自己的需求二次开发、自由扩展。

:jigsaw: **每一个工具都是一块可自由拼接的乐高积木，而开源精神，就是我们搭建理想工具世界的地基。**

无论你是热衷于构建个性化博客，还是想为社区打造更多连接点，欢迎加入这个探索的过程，一起把内容创作的生态做得更有趣、更有温度。
