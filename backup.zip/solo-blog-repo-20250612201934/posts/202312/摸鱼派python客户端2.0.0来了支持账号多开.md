title: 摸鱼派python客户端2.0.0来了～～～,支持账号多开
date: '2023-12-03 21:02:52'
updated: '2023-12-04 14:04:29'
tags: [python, 客户端, 命令行, 社区]
permalink: /articles/2023/12/03/1701608571858.html
---
![](https://b3logfile.com/bing/20200119.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在去年元旦的时候，因为没有出去玩无聊，给摸鱼派写了一个python客户端，那时候不会python，所以写的很烂。https://fishpi.cn/article/1641135630423

这周末由于周六爬山累到了，一天都在休息，于是想重构一下之前的屎山。并且加了一些功能。

于是 [fishpi-pyclient 2.0.0](https://github.com/gakkiyomi/fishpi-pyclient) 来了。

2.0.0版本最大的特点就是支持账号多开，一键切换账号。

![fenshen.png](https://file.fishpi.cn/2023/12/账号分身-0a25be81.png)

## 安装方式

### MacOS版本

[下载连接](https://github.com/gakkiyomi/fishpi-pyclient/releases/download/v2.0.0/fishpi-pyclient)

执行如下命令

1. ```bash
   chmod a+x ./fishpi-pyclient
   ```
2. ```bash
   ./fishpi-pyclient
   ```

然后需要在偏好设置这里,如下图:
![WechatIMG482.jpg](https://file.fishpi.cn/2023/12/WechatIMG482-3c599a0e.jpg)

### 使用pip安装

```python
pip install fishpi-pyclient
```

![image.png](https://file.fishpi.cn/2023/12/image-f8a6b613.png)

## 分身账号添加

1. 通过配置文件![image.png](https://file.fishpi.cn/2023/12/image-c21b2894.png)
2. 可通过#change username 来切换。
   
   ![image.png](https://file.fishpi.cn/2023/12/image-70eddd50.png)

具体功能大家可以下载尝试

## 问题

1. 由于本人没有windows机器，所以暂未在windows上测试
2. 由于本人python并不是很熟悉，也在逐渐学习当中，如果大家对python很了解或者很感兴趣，也可以在github[源码](https://github.com/gakkiyomi/fishpi-pyclient)或者本帖留言提意见让我学习一下，感谢🙏

