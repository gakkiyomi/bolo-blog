title: “V2rayU”将对您的电脑造成伤害。您应该将它移到废纸篓 的临时解决方案
date: '2023-07-07 14:48:20'
updated: '2023-07-07 14:49:23'
tags: [运维, v2ray, 科学上网]
permalink: /articles/2023/07/07/1688712500541.html
---
由于v2rayU的证书过期。正在使用3.3.0版本的v2rayU会频繁弹出窗口

![image.png](https://b3logfile.com/file/2023/07/image-hKNQyZa.png)

### 临时解决办法

1. 先打开一次，报错不用管，终端跑以下命令，输入登录密码按回车，密码不会显示

```
sudo /usr/bin/codesign --force --deep --sign - /Applications/V2rayU.app
sudo /usr/bin/codesign --force --deep --sign - ~/.V2rayU/V2rayUTool
sudo /usr/bin/codesign --force --deep --sign - ~/.V2rayU/v2ray-core/v2ray
```

2. 在应用程序里找到他，右键，显示简介，勾选 覆盖恶意软件保护

![image](https://user-images.githubusercontent.com/17966333/250444425-c8865806-64da-4e64-9611-b16171ea912f.png)

然后再打开就可以用了，用不了就重头再来一次
