title: Postgres数据清理过程
date: '2023-04-24 10:50:28'
updated: '2023-06-01 17:40:54'
tags: [数据库, Postgres]
permalink: /articles/2023/04/24/1682304628546.html
---
## 查看数据量大的表

~~~sql
 SELECT table_schema || '.' || table_name AS table_full_name, pg_size_pretty(pg_total_relation_size('"' 
    || table_schema || '"."' || table_name || '"')) AS size
FROM information_schema.tables 
ORDER BY
pg_total_relation_size('"' || table_schema || '"."' || table_name || '"') DESC limit 100
~~~

![image.png](https://b3logfile.com/file/2023/04/image-FFnNM3l.png)

## 查看数据量大的字段

~~~sql
select
 sum(pg_column_size(path_analyze_result)) as path,
 sum(pg_column_size(object_analyze_result)) as object,
 sum(pg_column_size(correlation_analyze_result)) as correlation
from nap_policy_service_request;

   path   |  object   | correlation
----------+-----------+-------------
 32640372 | 252413523 | 48469497241
(1 row)
~~~

## 数据处理

如果是一些不重要的数据，可以直接删除

`delete from table_name`

然后需要清除索引和TOAST数据

`VACUUM FULL table_name;`

~~~sql
nap=> \dt+ table_name
                              List of relations
 Schema |            Name            | Type  | Owner |  Size   | Description
--------+----------------------------+-------+-------+---------+-------------
 public | table_name | table | nap   | 3047 MB |
(1 row)
~~~

如果不能删除,可以进行数据迁移，分库分表等处理
