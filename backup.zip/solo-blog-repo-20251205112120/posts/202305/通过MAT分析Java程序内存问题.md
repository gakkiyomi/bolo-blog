title: 通过MAT分析Java程序内存问题
date: '2023-05-17 09:28:33'
updated: '2023-06-01 17:40:46'
tags: [排错, JAVA]
permalink: /articles/2023/05/17/1684286913801.html
---
![](https://b3logfile.com/bing/20211215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 查看程序内存占用

`kubectl top pod -nsky`

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165227-rlzgk9e.png?imageView2/2/interlace/1/format/webp)

‍

## 进入目标容器

`kubectl exec -it -nsky <pod名称> bash`

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165251-cisxnc6.png?imageView2/2/interlace/1/format/webp)

获取 java 程序进程号

`jps`

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165341-m6lql3i.png?imageView2/2/interlace/1/format/webp)

‍

## 保存堆栈信息

`jmap -dump:live,format=b,file=<文件保存位置> <java进程号>`

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165417-9p2yuwz.png?imageView2/2/interlace/1/format/webp)

‍

## 通过 MAT 分析内存

## pipeline 分析案例

1、通过 MAT 打开堆栈信息

2、打开自动生成的内存溢出分析

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165653-x104atf.png?imageView2/2/interlace/1/format/webp)‍

发现 ConcurrentSkipListMap 占用了大量内存

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165712-bwbn63j.png?imageView2/2/interlace/1/format/webp)

点开 detail

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165742-3bb49nw.png?imageView2/2/interlace/1/format/webp)

单击大对象

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165754-s7ekgba.png?imageView2/2/interlace/1/format/webp)

选择 List objects->with incoming references 查看持有该对象引用的对象

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165825-x37y1op.png?imageView2/2/interlace/1/format/webp)

‍

发现有很多的 grpc channel 对象

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165838-sgfb18k.png?imageView2/2/interlace/1/format/webp)

查看代码发现重复创建 channel

![image](https://b3logfile.com/file/2023/05/siyuan/1542847893188/assets/image-20230329165852-z63pw4s.png?imageView2/2/interlace/1/format/webp)

‍

bug fixed
