title: ES ILM策略
date: '2024-10-30 12:51:41'
updated: '2024-10-30 12:51:41'
tags: [ElasticSearch, 数据库]
permalink: /articles/2024/10/30/1730263901140.html
---
![](https://b3logfile.com/bing/20230607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Index Lifecycle Management（ILM）策略

Elasticsearch可以通过 **Index Lifecycle Management (ILM)**  策略自动创建每日滚动索引。以下是一个创建每日滚动索引的示例，配合ILM策略可以让索引根据数据增长自动创建新的每日索引，并在数据老化时移动到温或冷存储中。

# 配置ILM策略

首先，创建一个ILM策略来定义索引的生命周期，策略包括热（hot）、温（warm）和冷（cold）阶段。

```bash

PUT_ilm/policy/daily-log-policy

{

"policy":{

"phases":{

"hot":{# 热存储阶段，用于写入新数据

"actions":{

"rollover":{# 数据超过条件时，自动创建新的索引

"max_age":"1d",# 索引1天后滚动

"max_size":"50gb"# 或者当索引达到50GB时滚动

}

        }

      },

"warm":{# 温存储阶段，用于较少访问的数据

"min_age":"3d",# 数据进入温存储的最小年龄为3天

"actions":{

"forcemerge":{# 压缩索引，减少资源占用

"max_num_segments":1

          }

        }

      },

"cold":{# 冷存储阶段，几乎不访问的数据

"min_age":"7d",

"actions":{

"freeze":{}# 冻结索引，节省内存和CPU

        }

      },

"delete":{# 删除阶段

"min_age":"30d",

"actions":{

"delete":{}# 索引存储超过30天后自动删除

        }

      }

    }

  }

}

```

# 创建ES索引模版并使用ILM策略

然后，创建一个索引模板，让新数据根据定义的ILM策略按天生成新的索引。

```bash

PUT_index_template/logs-template

{

"index_patterns": ["logs-*"],    # 匹配名称前缀为logs-的索引

"template":{

"settings":{

"number_of_shards":1,#分片数量

"number_of_replicas":1,#副本数量

"index.lifecycle.name":"daily-log-policy",# 应用ILM策略

"index.lifecycle.rollover_alias":"logs"# 设置别名，供rollover使用

},

"aliases":{

"logs":{}# 创建一个别名“logs”

    }

  }

}

```

# 创建初始索引并开始滚动

首次创建时，需要创建一个初始索引`logs-000001`，并与`logs`别名关联，之后的每日索引会在数据量达到滚动条件后自动创建。

```bash

PUTlogs-000001

{

"aliases":{

"logs":{

"is_write_index":true# 将logs别名指向初始写入索引

}

  }

}

```

# 开始索引数据

当Filebeat或其他数据源向Elasticsearch写入数据时，只需指定`logs`别名。ILM策略会确保每天创建新的索引（如 `logs-000002`, `logs-000003` 等），并自动将旧索引转移到温、冷阶段，最后根据生命周期删除。

# 总结

通过这种方式，可以实现按天自动创建索引，ILM策略会根据条件自动进行滚动，无需手动创建每日索引，索引的生命周期管理也更加智能和高效。
