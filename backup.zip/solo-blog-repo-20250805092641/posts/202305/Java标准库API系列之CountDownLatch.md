title: Java 标准库API系列之CountDownLatch
date: '2023-05-28 18:39:56'
updated: '2023-06-01 17:38:11'
tags: [JAVA]
permalink: /articles/2023/05/28/1685409198357.html
---
![](https://b3logfile.com/bing/20210120.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 继续 Java标准库API系列文章，今天要讲的是一个同步利器。CountDownLatch是Java中的一个同步工具类，它允许一个或多个线程等待一组事件的发生，直到所有事件都发生后才能继续执行。CountDownLatch通过一个计数器来实现，初始化一个正整数，每当一个事件发生时，计数器减1，当计数器为0时，表示所有事件都已发生，等待的线程可以继续执行。

在没有`CountDownLatch`之前，我们想让线程等待其他线程执行完之前等待话，需要使用到`Thread`类的`join方法`

就像之前 [Java 标准库API系列之Exchanger](http://gakkiyomi.me/articles/2023/05/28/1685270396773.html)的例子里的一样。

有了`CountDownLatch`之后等待其他多个线程执行完成的需求就可以使用更佳方便的API了。

`CountDownLatch`的常用方法有两个：

* void countDown()：表示一个事件已经发生，将计数器减1；
* void await()：等待所有事件发生，如果计数器不为0，则一直等待。

以下是一个使用CountDownLatch进行线程同步的示例代码：

~~~java
import java.util.concurrent.CountDownLatch;

public class CountDownLatchExample {
    private static CountDownLatch latch = new CountDownLatch(3);

    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Thread(() -> {
            System.out.println("Task 1 is running");
            latch.countDown();
        });

        Thread t2 = new Thread(() -> {
            System.out.println("Task 2 is running");
            latch.countDown();
        });

        Thread t3 = new Thread(() -> {
            System.out.println("Task 3 is running");
            latch.countDown();
        });

        t1.start();
        t2.start();
        t3.start();

        latch.await();

        System.out.println("All tasks are completed");
    }
}
~~~

在上述代码中，`CountDownLatchExample`类中的latch变量是一个`CountDownLatch`对象，用于等待三个子线程执行完毕。在`main()`方法中，创建了三个子线程t1、t2和t3，它们分别调用了`latch.countDown()`方法表示任务执行完毕。主线程在启动三个子线程后调用了`latch.await()`方法等待所有任务执行完毕，当计数器减为0时，主线程才能继续执行。
